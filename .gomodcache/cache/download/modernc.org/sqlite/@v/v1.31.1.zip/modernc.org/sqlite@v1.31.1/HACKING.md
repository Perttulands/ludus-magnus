Please do not tag commits unless all builders at
https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2fsqlite are
happy.

Since 2024-03-12 it should be no more necessary to manually tag releases at
all as the repo is now set to be tagged automatically.
